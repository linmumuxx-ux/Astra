<template>
  <div ref="dashboardElement" class="dashboard-page" data-testid="dashboard-page">
    <OfficeScene
      :teams="teams"
      :employees="employees"
      :selected-id="selectedId"
      :query="query"
      :focused-team-id="activeTeamId"
      @select="selectEmployee"
      @focus="locateTeam"
    />
    <OfficeSummary :employees="employees" :teams="teams" :active-team-id="activeTeamId" />
    <RealtimeActivityBar :events="store.events" :employees="store.employees" @select="selectFromActivity" />
    <EmployeeDetailPanel
      v-if="detailEmployee"
      :employee="detailEmployee"
      :team-name="detailTeamName"
      @close="closeDetail"
    />
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import EmployeeDetailPanel from '@/components/workspace/EmployeeDetailPanel.vue'
import OfficeScene from '@/components/office/OfficeScene.vue'
import OfficeSummary from '@/components/office/OfficeSummary.vue'
import RealtimeActivityBar from '@/components/workspace/RealtimeActivityBar.vue'
import { groupOfficeTeams, officeTeamIdentity } from '@/features/office/officeLayout'
import { adaptWorkspaceEmployees, workspaceEmployeeMatches } from '@/features/workspace/eventAdapter'
import { useAstraStore } from '@/stores/astra'

const route = useRoute()
const store = useAstraStore()
const dashboardElement = ref<HTMLElement | null>(null)
const selectedId = ref('')
const detailId = ref('')
const activeTeamId = ref('')

const query = computed(() => typeof route.query.q === 'string' ? route.query.q.trim() : '')
const employees = computed(() => adaptWorkspaceEmployees(store.employees, store.tasks, store.events))
const teams = computed(() => groupOfficeTeams(employees.value))
const detailEmployee = computed(() => employees.value.find((employee) => employee.id === detailId.value) ?? null)
const detailTeamName = computed(() => detailEmployee.value ? officeTeamIdentity(detailEmployee.value).name : '')

function locateTeam(teamId: string, smooth = true) {
  activeTeamId.value = teamId
  const target = teamId ? document.getElementById(`team-${teamId}`) : dashboardElement.value
  if (smooth) target?.animate(
    [{ filter: 'brightness(1)' }, { filter: 'brightness(1.08)' }, { filter: 'brightness(1)' }],
    { duration: 620, easing: 'ease-out' },
  )
}

function selectEmployee(id: string) {
  selectedId.value = id
  detailId.value = id
  const employee = employees.value.find((item) => item.id === id)
  if (employee) activeTeamId.value = officeTeamIdentity(employee).id
}

function closeDetail() {
  detailId.value = ''
  selectedId.value = query.value
    ? employees.value.find((employee) => workspaceEmployeeMatches(employee, query.value))?.id ?? ''
    : ''
}

async function selectFromActivity(id: string) {
  const employee = employees.value.find((item) => item.id === id)
  if (employee) {
    await nextTick()
    locateTeam(officeTeamIdentity(employee).id)
  }
  selectEmployee(id)
}

watch(query, async (value) => {
  if (!value) {
    selectedId.value = detailId.value
    return
  }
  const match = employees.value.find((employee) => workspaceEmployeeMatches(employee, value))
  selectedId.value = match?.id ?? ''
  detailId.value = ''
  if (match) {
    await nextTick()
    locateTeam(officeTeamIdentity(match).id)
  }
}, { immediate: true })

watch(employees, (items) => {
  if (detailId.value && !items.some((employee) => employee.id === detailId.value)) closeDetail()
})

onMounted(() => { if (!store.employees.length && !store.loading) store.refresh() })
</script>

<style scoped>
.dashboard-page{position:relative;height:calc(100dvh - 68px);min-height:650px;overflow:hidden;background:#e8f2ed}.dashboard-page :deep(.activity-bar){position:absolute;z-index:32;right:0;bottom:0;left:0}
@media(max-width:680px){.dashboard-page{height:calc(100dvh - 60px);min-height:680px;overflow:hidden}}
</style>
